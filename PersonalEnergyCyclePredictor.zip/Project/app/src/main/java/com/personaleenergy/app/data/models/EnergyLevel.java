package com.personaleenergy.app.data.models;

public enum EnergyLevel {
    HIGH, MEDIUM, LOW
}

